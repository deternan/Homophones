'''
version: September 08, 2021 09:12 AM
Last revision: September 14, 2021 11:15 AM

Author : Chao-Hsuan Ko
'''

import tkinter as tk
from tkinter import END

from crawler.Crawler import Crawler
from crawler.Preprocessing import Preprocessing
from PostProcessing import PostProcessing
from image.Model import Model

window = tk.Tk()
window.title('Patent')
window.geometry('350x300')
#US20210167320A1

def button_Processing():
    if (len(text_1.get()) != 0):
        label_2['text'] = '程式執行中'
        T.insert(END, text_1.get()+'\n')
        T.update()
        crawler = Crawler()
        crawler.get_pattentID(text_1.get())
        stateCode = crawler.get_pattentID(text_1.get())
        label_2['text'] = ' '
    else:
        label_2['text'] = '編號輸入錯誤'
        T.insert(END, '編號輸入錯誤\n')
        T.update()

    if stateCode == 200:
        T.insert(END, '抓取資料完成\n')
        T.update()
        label_2['text'] = '資料處理中'
        Preprocessing(text_1.get())
        label_2['text'] = '資料後處理中'
        PostProcessing(text_1.get())
        T.insert(END, '資料後處理結束\n')
        T.update()
        label_2['text'] = '數字辨識中'
        #Model.get_pattentID(text_1.get())
        Model(text_1.get())
        label_2['text'] = '程式執行完成'
        T.insert(END, '程式執行完成\n')
        T.update()
    elif stateCode == 404:
        label_2['text'] = '來源資料錯誤\n'
        T.insert(END, '來源資料錯誤')
        T.update()
    else:
        label_2['text'] = '不明錯誤'
        T.insert(END, '不明錯誤\n')
        T.update()


# Input Id (Layout)
label_1 = tk.Label(window, text='輸入專利編號', fg='#263238', font=('Arial', 12))
label_1.grid(column=0, row=0, padx=5, pady=20)
text_1 = tk.Entry(window, width=20)
text_1.grid(column=1, row=0, padx=5, pady=20)
button_1 = tk.Button(window, text='Search', command = button_Processing)
button_1.grid(column=0, row=1, padx=0, pady=10)
label_2 = tk.Label(window, text='', fg='#263238', font=('Arial', 12))
label_2.grid(column=1, row=1, padx=0, pady=20)

T = tk.Text(window, height=10, width=20)
T.grid(column=0, row=2, padx=15, pady=0)

window.mainloop()


