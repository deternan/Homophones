'''
version: August 31, 2021 11:00 AM
Last revision: September 08, 2021 03:37 PM

Author : ITING.TU / Chao-Hsuan Ko
'''

import os.path
import requests
from bs4 import BeautifulSoup
from tqdm import tqdm


class Crawler():
    stateCode = ''

    def __init__(self):
        self.description = ""
        self.claim = ""

    # 抓取頁面中描述的部分
    def get_description(self, soup):
        description_resource = soup.findAll("div", class_="description-line") or soup.findAll("div",
                                                                                              class_="description-paragraph")
        description_content = [content.getText() for content in description_resource]
        self.description = description_content
        return 0

    # 抓取頁面中cliam的部分
    def get_claim(self, soup):
        claim_resouce = soup.findAll("div", class_="claim-text")
        claim_text = [text.getText() for text in claim_resouce]
        self.claim = claim_text
        return 0

    # 儲存圖片(沒有用到seleium)
    def get_image(self, patent_id, soup):
        img_count = 1  # 計算圖片的數量
        # 是否存在images的資料夾，若沒有則建立
        if not os.path.exists('output/' + patent_id + "/images"):
            os.mkdir('output/' + patent_id + "/images")
        # 找到所需要的image
        img_resouse = soup.findAll('meta', {'itemprop': "full"})
        for img in img_resouse:
            with open('output/' + patent_id + "/images/" + str(img_count + 1) + ".jpg", 'wb') as file:
                file.write(requests.get(img['content']).content)
            img_count += 1
        return 0

    # 儲存description檔案、claim檔案
    def save_file(self, patent_id):
        # 儲存description檔案
        if self.description:
            description_file = open('output/' + patent_id + "/description.txt", 'w', encoding='utf-8')
            description_file.write(str(self.description))
        # 儲存claim檔案
        if self.claim:
            claim_file = open('output/' + patent_id + "/claim.txt", 'w', encoding='utf-8')
            claim_file.write(str(self.claim))
        # print("檔案儲存完成")
        return 0

    def main_processing(self, patent_id):
        url = "https://patents.google.com/patent/"
        # 搜尋每一個頁面的所有資料
        for id in tqdm(patent_id):
            respones = requests.get(url + str(id))
            stateCode = respones.status_code
            #print('QQ', stateCode)
            if stateCode == 200:
                # 若有真實資料 則建立資料夾
                if not os.path.exists('output/' + id):
                    os.mkdir('output/' + id)
                    patent.stateCode = 200
                    # 抓取頁面的資訊
                    soup = BeautifulSoup(respones.text, "html.parser")
                    patent.get_description(soup)
                    patent.get_claim(soup)
                    patent.get_image(id, soup)
                    patent.save_file(id)
        return stateCode


    # 接收 GUI 傳入之 Patten Id
    def get_pattentID(self, getId):
        patent_id = []
        patent_id.append(getId)
        stateCode = patent.main_processing(patent_id)
        return stateCode


patent = Crawler()
