import numpy as np
import cv2
from time import time
from random import randint
from collections import OrderedDict
import os

# Configure
ROOT_PATH = './'
SAVE_PATH = 'result'
SAVE_NAME = 'res_{}'
MAP_PATH = 'US20200401227.txt'
img_list = ['f1.png', 'f2.png']

def match_digits(model, img):
    score = model.predict(img)
    ans = np.argmax(score)
    return ans

def find_letters(filename):
    im = cv2.imread(filename)
    start = time()
    # Preprocess
    gray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray,(5,5),0)
    thresh = cv2.adaptiveThreshold(blur,255,1,1,11,2)

    # Find ROI
    contours, _ = cv2.findContours(thresh,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

    candidate = dict()

    # find all letters
    for cnt in contours:
        if cv2.contourArea(cnt) > 50:
            [x,y,w,h] = cv2.boundingRect(cnt)
            # check if it is letter
            if (h > 20 and w > 10 and h < 60 and w < 60):
                #roi = im[y:y+h, x:x+w]
                if candidate.get(y+h, None) == None:
                    candidate[y+h] = []
                    candidate[y+h].append([x,y,w,h])
                else:
                    candidate[y+h].append([x,y,w,h])

    bias = []
    candidate = OrderedDict(sorted(candidate.items()))

    final = []

    for key, val in candidate.items():
        if key in bias:
            continue
        bias = list(range(key+1, key+3))
        temp = val

        for i in bias:
            if i in candidate.keys():
                temp += candidate.get(i)

        stop = -1
        words = []
        h_all = []
        num = 0
        if (len(temp) > 1):
            temp = sorted(temp, key=lambda elem: elem[0])
            #print(key, temp)
            for (x, y, w, h) in temp:
                h_all.append(h)
                if stop == -1:
                    num = 1
                    stop = (x+w, y+h)
                    words.append((x,y,w,h))
                else:
                    if (x - stop[0] < 15):
                        stop = (x + w, y + h)
                        words.append((x,y,w,h))
                        num += 1
                    else:
                        final.append(words)
                        words = []
                        stop = -1
            if stop != -1:
                final.append(words)
        else:
            h_all.append(temp[0][3])

    return final, round(np.mean(h_all))

def get_txt_map(filename):
    with open(filename, 'r') as f:
        lines = f.readlines() 

    txt_map = dict()
    for line in lines:
        line = line.strip()
        key, content = line.split(',')
        txt_map[key] = content

    return txt_map

def get_white_area(img, x, y, w, h):
    img_h, img_w, _ = img.shape
    new_x = x
    new_y = y
    is_find = False
    for col in range(y, img_h - h - 3):
        for raw in range(x, img_w - w - 3):
            area = img[col:col+h, raw:raw+w, :]
            if np.mean(area) == 255:
                new_x = raw
                new_y = col
                is_find = True
                break
        if (is_find):
            break

    return (new_x, new_y)

def match_digits_absdiff(img, new_size, patterns):
    img_rm = cv2.resize(img, (new_size, new_size))
    min_val = new_size * new_size * 3
    threashold = 2100 * float(new_size / 42)
    min_idx = -1
    for i, template in enumerate(patterns):
        tem_rm = cv2.resize(template, (new_size, new_size))
        diff = cv2.absdiff(img_rm, tem_rm)
        _, diff = cv2.threshold(diff, 0, 255, cv2.THRESH_BINARY)
        diff_val = np.sum((diff > 250))

        if diff_val < min_val:
            min_idx = i
            min_val = diff_val

    if (min_val > threashold):
        return '?'
    else: 
        return min_idx 

def get_patterns():
    patterns = []

    for i in range(10):
        img = cv2.imread('newest/t{}.png'.format(i))
        h, w, _ = img.shape
        patterns.append(img)

    return patterns

def patent_test():
    """
    Read digits from the picture of patent document and draw text on the picture
    """
    # Create save folder
    if not os.path.exists(SAVE_PATH):
            os.mkdir(SAVE_PATH)

    txt_map = get_txt_map(MAP_PATH)

    start = time()
    for img_name in img_list:
        res, h_mean = find_letters(ROOT_PATH + img_name)
        img = cv2.imread(ROOT_PATH + img_name)

        results = []
        patterns = get_patterns()
        # Merge text slice to word
        for rects in res:
            ans = ''
            if len(rects) < 3:
                continue
            for x,y,w,h in rects:
                roi = img[y:y+h, x:x+w, :]
                text = match_digits_absdiff(roi, h_mean, patterns)
                ans += str(text)
            
            if (len(ans) < 5):
                results.append(ans)
        # Sort
        results_sort = sorted(results)

        # Draw text on the picture
        area_w = 0
        area_h = 0
        textArea = []

        # Calculate area to draw all text
        for key in results_sort:
            if key in txt_map.keys():
                content = txt_map.get(key)
                content = key + ' ' + content
                textArea.append(content)
                (txt_w, txt_h), baseline = cv2.getTextSize(content, cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, 1)
                if (txt_w > area_w):
                    area_w = txt_w + 10
                area_h += txt_h

        if (len(textArea) != 0):
            # Get all white area in picture
            white_x, white_y = get_white_area(img, 10, 10, area_w, area_h)

            for content in textArea:
                (txt_w, txt_h), baseline = cv2.getTextSize(content, cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, 1)
                cv2.putText(img, content, (white_x + 10, white_y + txt_h), cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, (255, 0, 0), 1, cv2.LINE_AA)
                white_y += (txt_h + baseline)
                
        cv2.imwrite('{}/{}'.format(SAVE_PATH, SAVE_NAME.format(img_name)), img)
    print('TIme: {0}s'.format(time() - start))

def main():
    patent_test()


if __name__ == '__main__':
    main()