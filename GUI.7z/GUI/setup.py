from distutils.core import setup
import py2exe
import sys

sys.argv.append('py2exe')
#setup(console=["GUI.py"])
#setup(windows=['GUI.py'])
setup(
    windows=[{"script" : "GUI.py"}],
    options = {'py2exe': {'bundle_files': 1, 'compressed': True}},
    zipfile = None,
)

#-------------------------------------------------------------

# from distutils.core import setup
# import py2exe
#
# INCLUDES = []
#
# options = {
#     "py2exe" :
#         {
#             "compressed" : 1, # 壓縮
#             "optimize" : 2,
#             "bundle_files" : 1, # 所有檔案打包成一個 exe 檔案
#             "includes" : INCLUDES,
#             "dll_excludes" : ["MSVCR100.dll"]
#         }
# }
#
#
# setup(
#     options=options,
#     description = "Patent GUI",
#     zipfile=None,
#     console = [{"script":'GUI.py'}])